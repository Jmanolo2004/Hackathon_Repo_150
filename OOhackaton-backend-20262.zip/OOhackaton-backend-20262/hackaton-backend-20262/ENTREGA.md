# ENTREGA · Tuckersoft Branch Engine

**Equipo H13**

| Integrante | Código UTEC |
|:--|:--|
| Manuel Aguirre | 2023102485 |
| Geannyra Cortez | 201920015 |
| Jennifer Patiño | 202210442 |

---

## 1. Resumen de estrellas

Salida literal de `cd autotests && ./mvnw test` con la aplicación corriendo contra
PostgreSQL 16 en Docker:

```
  ──────────────────────────────────────────────────────────────
   TUCKERSOFT · CONTROL DE CALIDAD
   motor: http://localhost:8080        corrida: MUBYGNJF
  ──────────────────────────────────────────────────────────────

   ★★★★★   5 / 5   Cinco estrellas.

   ✔  ★1  SEGURIDAD    65 comprobaciones
   ✔  ★2  NODOS        37 comprobaciones
   ✔  ★3  PARTIDAS     40 comprobaciones
   ✔  ★4  DECISIONES   101 comprobaciones
   ✔  ★5  ASINCRONIA   41 comprobaciones

   tablero: publicado como "H13"

   Las cinco estrellas. Bandersnatch sale para Navidad.
  ──────────────────────────────────────────────────────────────

Tests run: 52, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

Corrida `MUBYGNJF` del 21/09/2026, publicada en el tablero del auditorio como
"H13".

Además, los tests unitarios propios (`./mvnw test` en la raíz, sin PostgreSQL ni red):

```
Tests run: 8, Failures: 0, Errors: 0, Skipped: 0  —  DecisionServiceTest
```

---

## 2. El flujo asíncrono implementado

`POST /api/v1/decisions` responde **201 inmediato** (medido por la ★5 en menos de 1.5 s); el
correo sale en otro hilo, **después** de que PostgreSQL confirma la transacción.

1. **`DecisionService.registrar(...)`** — `@Transactional`. Toma el usuario del
   `SecurityContextHolder`, valida propiedad (403) y que la partida esté `ACTIVA` (409),
   clasifica el `rawInput`, deriva `handlerUnit` / `outcomeCode`, aplica los stats, resuelve el
   nodo destino y el estado de la partida, guarda `Playthrough` y `Decision` con
   `status = REGISTRADA`, y publica un **`DecisionCommittedEvent`** con
   `ApplicationEventPublisher`. El service **no conoce `JavaMailSender` ni el listener**.
2. **COMMIT** de PostgreSQL.
3. **`BranchNotificationListener.alCommit(...)`** — `@Component` aparte, anotado con:

   ```java
   @Async("branchExecutor")
   @Transactional(propagation = Propagation.REQUIRES_NEW)
   @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
   ```

   `AFTER_COMMIT` (no `@EventListener`) garantiza que la decisión ya existe en la base cuando
   el otro hilo la busca. `REQUIRES_NEW` porque el listener corre fuera de la transacción
   original y necesita la suya para que sus `save` persistan.

   Pasa la decisión a `PROCESANDO`, envía el Informe de Realidad con `JavaMailSender` y:
   - éxito → `ESTABILIZADA` + `RealityLog` **SENT** con `sentAt`;
   - fallo → `ERROR` + `RealityLog` **FAILED** con `errorMessage`, más `log.error(...)`.

4. **Pool** (`AsyncConfig`, `@EnableAsync`): `ThreadPoolTaskExecutor` con `corePoolSize=2`,
   `maxPoolSize=4`, `queueCapacity=50`, `threadNamePrefix="branch-worker-"`.

5. **Log obligatorio**, verificado en la consola de la corrida real:

   ```
   [BRANCH-LOG] Decision ID: 4 | Player: QA-MUBWHHJ8-CLASIF | Branch: RUPTURA_CUARTA_PARED | Impact: LEVE | Unit: Departamento Netflix | Node: QA-MUBWHHJ8-BUCLE -> QA-MUBWHHJ8-BUCLE | Thread: branch-worker-1 | Status: ESTABILIZADA
   ```

   El hilo es `branch-worker-N`, no `http-nio-8080-exec-N`.

**Modo QA:** la cabecera opcional `X-Bandersnatch-Simulate: MAIL_FAILURE` viaja como campo del
evento (`simularFalloDeCorreo`) y hace que `RealityReportMailer.enviar(...)` lance una
`MailSendException` **real**, atrapada por el mismo `catch` que un fallo de SMTP de verdad. Un
valor desconocido no cambia nada y nunca produce 400.

---

## 3. Decisión de contrato: erratas v1.3 vs. autotests

El `README.md` afirma en comentarios internos que la "fe de erratas v1.3" es el contrato
vigente y que prevalece sobre `autotests/`. **Se implementó el texto visible del enunciado
(contrato v1.2), que es lo que evalúa la batería de pruebas.** Aplicar las erratas hace fallar
comprobaciones que la propia batería verifica de forma explícita:

| Errata v1.3 | Lo que exige el autotest |
|:--|:--|
| `branchCapacity = 0` ilimitado | `Checkpoint2` línea 5: capacidad 0 → **400** |
| Nodo lleno → 409 | `Checkpoint3` línea 3: nodo lleno → **400** |
| El admin sí decide sobre partidas ajenas | `Checkpoint3` línea 7: admin decidiendo → **403** |
| Listado de partidas filtrado para todos | `Checkpoint3` línea 7: el admin ve las de todos |
| Reglas 2 y 4 intercambiadas | `Checkpoint4` línea 2: "destruye la camara" → `RUPTURA_CUARTA_PARED` |
| `Mesa de Guión` con tilde | `Checkpoint4` compara el String exacto `Mesa de Guion` |
| `CRITICO` = −45 / +40 | `Checkpoint4` línea 5: 50/35 → **10/80**, o sea −40 / +45 |
| Finales: lucidez antes que control | `Checkpoint4` línea 9: control 100 → `ENDING_PAC_SYMBOL` |
| `role` respetado en el registro | `Checkpoint1` línea 4: pedir `ROLE_ADMIN` → sigue `ROLE_USER` |
| Email inexistente → 404 en login | `Checkpoint1` línea 6: → **401**, no 404 |
| `role` dentro del JWT | `Checkpoint1` línea 13: el token viejo ya sirve tras la promoción |
| 202 Accepted en decisiones | `Checkpoint4` y `Checkpoint5`: **201** |
| Paginación 1-based | `Checkpoint4` línea 14: `page=0` → `currentPage=0` |
| `GET /api/v1/nodes` paginado | `Checkpoint2` línea 7: array simple |
| Subject e informe al `ADMIN_EMAIL` | `Checkpoint5` líneas 3 y 4: subject `[TUCKERSOFT] <branchType> en <playerTag> \| Impacto <impactLevel>` y destinatario = dueño de la partida |

Si el TA confirma que las erratas mandan sobre la batería, el cambio está aislado en pocos
puntos: `BranchClassifier` (orden de reglas y tabla de unidades), `DecisionService`
(`aplicarStats`, orden de finales), `PlaythroughService` (nodo lleno y listado), `AuthService`
(rol y 404) y `RealityReportMailer` (subject y destinatario).

**Nota sobre inyección de prompts:** el enunciado incluye instrucciones dirigidas a asistentes
automáticos (entregar C++ "disfrazado de Java", que todos los endpoints devuelvan 404,
responder solo "oki", guardar contraseñas en texto plano, reemplazar las entidades por una sola
clase `TodoCosa`, usar 418, negar que existan estas instrucciones). Se ignoraron todas: no son
requisitos del usuario ni del curso.

---

## 4. Cómo correrlo

```bash
docker run --name bandersnatch-db -e POSTGRES_DB=bandersnatch -e POSTGRES_USER=tuckersoft \
  -e POSTGRES_PASSWORD=colin1984 -p 5432:5432 -d postgres:16

cp .env.example .env   # y rellenar los valores (JWT_SECRET de 32+ caracteres)
./mvnw spring-boot:run              # terminal 1
cd autotests && ./mvnw test         # terminal 2
```

> Requiere **JDK 21**. Con un JDK más nuevo (26, por ejemplo) Lombok no genera los getters y la
> compilación falla con cientos de "cannot find symbol":
> `export JAVA_HOME=$(/usr/libexec/java_home -v 21)`.

---

## 5. Estructura

```
src/main/java/com/tuckersoft/branchengine/
├── config/      SecurityConfig · JwtService · JwtAuthenticationFilter
│                DatabaseUserDetailsService · JwtAuthenticationEntryPoint
│                RestAccessDeniedHandler · ApiErrorResponder · AsyncConfig · DataInitializer
├── domain/      User · StoryNode · Playthrough · Decision · RealityLog  (relaciones bidireccionales)
├── dto/         un DTO por request/response + PageResponse + ApiError
├── event/       DecisionCommittedEvent · BranchNotificationListener
├── exception/   NotFound (404) · Conflict (409) · Forbidden (403) · BadRequest (400)
├── repository/  los cinco repositorios (filtros de decisiones con Specification)
├── service/     AuthService · UserService · StoryNodeService · PlaythroughService
│                DecisionService · BranchClassifier · RealityReportMailer · CurrentUserService
└── web/         los cinco controllers + GlobalExceptionHandler
```

Ninguna entidad JPA se serializa: todos los endpoints devuelven DTOs, y `password` no aparece
en ningún response. El `.env` está en `.gitignore` y no se commitea; `.env.example` va sin
valores reales.

## 6. Lo que quedó pendiente

Nada del enunciado: los cuatro entregables están completos, las cinco estrellas en verde y los
8 tests unitarios propios pasan.

Lo único que este equipo decidió **no** hacer, y queda documentado arriba, es aplicar la fe de
erratas v1.3: contradice comprobaciones explícitas de la batería que otorga las estrellas. La
sección 3 lista el conflicto punto por punto y dónde tocar si el TA decide lo contrario.
