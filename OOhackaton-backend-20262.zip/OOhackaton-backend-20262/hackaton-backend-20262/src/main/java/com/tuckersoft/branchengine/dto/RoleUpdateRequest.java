package com.tuckersoft.branchengine.dto;

import jakarta.validation.constraints.NotBlank;

public record RoleUpdateRequest(
        @NotBlank(message = "el rol es obligatorio") String role) {
}
