package com.tuckersoft.branchengine.dto;

import jakarta.validation.constraints.NotBlank;

public record LoginRequest(
        @NotBlank(message = "el email es obligatorio") String email,
        @NotBlank(message = "la clave es obligatoria") String password) {
}
