package com.tuckersoft.branchengine.exception;

/** 403: autenticado, pero el recurso no es suyo. */
public class ForbiddenException extends RuntimeException {
    public ForbiddenException(String message) {
        super(message);
    }
}
