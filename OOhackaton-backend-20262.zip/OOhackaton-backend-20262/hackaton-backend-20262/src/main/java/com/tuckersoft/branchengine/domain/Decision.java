package com.tuckersoft.branchengine.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "decisions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Decision {

    public static final String REGISTRADA = "REGISTRADA";
    public static final String PROCESANDO = "PROCESANDO";
    public static final String ESTABILIZADA = "ESTABILIZADA";
    public static final String ERROR = "ERROR";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "playthrough_id", nullable = false)
    private Playthrough playthrough;

    /** Nodo de origen: el currentNode de la partida al momento de decidir. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "node_id", nullable = false)
    private StoryNode node;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String rawInput;

    @Column(nullable = false, length = 40)
    private String branchType;

    @Column(nullable = false, length = 20)
    private String impactLevel;

    @Column(nullable = false, length = 60)
    private String handlerUnit;

    @Column(nullable = false, length = 40)
    private String outcomeCode;

    @Column(length = 40)
    private String resolvedNodeCode;

    @Column(nullable = false, length = 20)
    private String status;

    @Column(nullable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant updatedAt;

    @OneToMany(mappedBy = "decision", fetch = FetchType.LAZY)
    @Builder.Default
    private List<RealityLog> realityLogs = new ArrayList<>();
}
