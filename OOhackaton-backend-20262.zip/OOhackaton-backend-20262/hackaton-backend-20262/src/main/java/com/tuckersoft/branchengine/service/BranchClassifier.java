package com.tuckersoft.branchengine.service;

import org.springframework.stereotype.Component;

import java.text.Normalizer;

/**
 * Clasificacion con reglas propias: misma entrada, mismo resultado. Sin IA ni servicios
 * externos. El orden de las reglas es parte del contrato: la primera que se cumple gana.
 */
@Component
public class BranchClassifier {

    public static final String OBEDIENCIA = "OBEDIENCIA";
    public static final String REBELDIA = "REBELDIA";
    public static final String SOSPECHA = "SOSPECHA";
    public static final String RUPTURA_CUARTA_PARED = "RUPTURA_CUARTA_PARED";
    public static final String ENTRADA_CORRUPTA = "ENTRADA_CORRUPTA";

    /** Minusculas y sin tildes, para que "CÁMARA", "cámara" y "camara" comparen igual. */
    public static String normalizar(String rawInput) {
        if (rawInput == null) return "";
        return Normalizer.normalize(rawInput, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase();
    }

    public String clasificar(String rawInput) {
        String texto = normalizar(rawInput);

        // Regla 1: ni una letra de la 'a' a la 'z'.
        if (!texto.matches(".*[a-z].*")) {
            return ENTRADA_CORRUPTA;
        }
        // Regla 2: la cuarta pared. Se evalua ANTES que la rebeldia, a proposito:
        // "destruye la camara" es RUPTURA_CUARTA_PARED, no REBELDIA.
        if (contiene(texto, "netflix", "camara", "espectador", "videojuego")) {
            return RUPTURA_CUARTA_PARED;
        }
        // Regla 3: sospecha.
        if (contiene(texto, "vigilan", "simbolo", "conspiracion")) {
            return SOSPECHA;
        }
        // Regla 4: rebeldia.
        if (contiene(texto, "rechaza", "destruye", "desobedece", "renuncia")) {
            return REBELDIA;
        }
        // Regla 5: por defecto.
        return OBEDIENCIA;
    }

    private static boolean contiene(String texto, String... claves) {
        for (String clave : claves) {
            if (texto.contains(clave)) return true;
        }
        return false;
    }

    /** Departamento que atiende la rama. Va sin tildes: los autotests comparan el String exacto. */
    public String unidadDe(String branchType) {
        return switch (branchType) {
            case OBEDIENCIA -> "Mesa de Guion";
            case REBELDIA -> "Control de Continuidad";
            case SOSPECHA -> "Oficina de Seguridad";
            case RUPTURA_CUARTA_PARED -> "Departamento Netflix";
            case ENTRADA_CORRUPTA -> "Archivo de Errores";
            default -> throw new IllegalArgumentException("Rama desconocida: " + branchType);
        };
    }

    public String consecuenciaDe(String branchType) {
        return switch (branchType) {
            case OBEDIENCIA -> "ADVANCE_MAIN_PATH";
            case REBELDIA -> "FORK_TIMELINE";
            case SOSPECHA -> "INJECT_WHITE_BEAR_SYMBOL";
            case RUPTURA_CUARTA_PARED -> "BREAK_FOURTH_WALL";
            case ENTRADA_CORRUPTA -> "DISCARD_INPUT";
            default -> throw new IllegalArgumentException("Rama desconocida: " + branchType);
        };
    }
}
