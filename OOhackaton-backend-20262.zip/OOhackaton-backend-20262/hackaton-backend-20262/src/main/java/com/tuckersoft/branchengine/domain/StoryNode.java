package com.tuckersoft.branchengine.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "story_nodes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StoryNode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 40)
    private String nodeCode;

    @Column(nullable = false, length = 80)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String sceneText;

    @Column(nullable = false)
    private Integer branchCapacity;

    @Column(nullable = false)
    private Integer currentBranches;

    /** nodeCode del siguiente nodo por la via normal. String, no FK. */
    private String primaryBranchCode;

    /** nodeCode del siguiente nodo cuando la realidad se rompe. String, no FK. */
    private String glitchBranchCode;

    @Column(nullable = false)
    private Instant createdAt;

    @OneToMany(mappedBy = "currentNode", fetch = FetchType.LAZY)
    @Builder.Default
    private List<Playthrough> playthroughs = new ArrayList<>();

    @OneToMany(mappedBy = "node", fetch = FetchType.LAZY)
    @Builder.Default
    private List<Decision> decisions = new ArrayList<>();

    public boolean estaLleno() {
        return currentBranches >= branchCapacity;
    }
}
