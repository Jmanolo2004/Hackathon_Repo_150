package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.StoryNode;
import com.tuckersoft.branchengine.dto.StoryNodeRequest;
import com.tuckersoft.branchengine.dto.StoryNodeResponse;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import com.tuckersoft.branchengine.repository.StoryNodeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StoryNodeService {

    private final StoryNodeRepository nodos;

    @Transactional
    public StoryNodeResponse crear(StoryNodeRequest peticion) {
        if (nodos.existsByNodeCode(peticion.nodeCode())) {
            throw new ConflictException("Ya existe un nodo con el codigo " + peticion.nodeCode());
        }
        StoryNode nodo = StoryNode.builder()
                .nodeCode(peticion.nodeCode())
                .title(peticion.title())
                .sceneText(peticion.sceneText())
                .branchCapacity(peticion.branchCapacity())
                .currentBranches(0)
                .primaryBranchCode(peticion.primaryBranchCode())
                .glitchBranchCode(peticion.glitchBranchCode())
                .createdAt(Instant.now())
                .build();
        return StoryNodeResponse.de(nodos.save(nodo));
    }

    @Transactional(readOnly = true)
    public List<StoryNodeResponse> listar() {
        return nodos.findAllByOrderByIdAsc().stream().map(StoryNodeResponse::de).toList();
    }

    @Transactional(readOnly = true)
    public StoryNodeResponse porId(Long id) {
        return nodos.findById(id).map(StoryNodeResponse::de)
                .orElseThrow(() -> new NotFoundException("No existe el nodo " + id));
    }
}
