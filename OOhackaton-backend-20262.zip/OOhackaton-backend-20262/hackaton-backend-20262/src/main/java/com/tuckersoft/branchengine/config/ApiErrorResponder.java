package com.tuckersoft.branchengine.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tuckersoft.branchengine.dto.ApiError;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.IOException;

/** Escribe el formato de error del enunciado en las respuestas que produce Spring Security. */
@Component
@RequiredArgsConstructor
public class ApiErrorResponder {

    private final ObjectMapper mapper;

    public void escribir(HttpServletRequest request, HttpServletResponse response,
                         int estado, String error, String mensaje) throws IOException {
        response.setStatus(estado);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        mapper.writeValue(response.getWriter(),
                ApiError.de(error, mensaje, request.getRequestURI()));
    }
}
