package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.exception.ForbiddenException;
import com.tuckersoft.branchengine.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/** El usuario del token. Ningun endpoint acepta el dueno por el cuerpo del request. */
@Service
@RequiredArgsConstructor
public class CurrentUserService {

    private final UserRepository usuarios;

    public User obtener() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || auth.getName() == null) {
            throw new ForbiddenException("No hay usuario autenticado en el contexto");
        }
        return usuarios.findByEmail(auth.getName())
                .orElseThrow(() -> new ForbiddenException("El usuario del token ya no existe"));
    }

    public boolean esAdmin(User usuario) {
        return User.ROLE_ADMIN.equals(usuario.getRole());
    }
}
