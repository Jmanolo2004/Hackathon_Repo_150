package com.tuckersoft.branchengine.dto;

import java.time.Instant;

/** Formato unico de error del enunciado, tambien para los 401 y 403 de Spring Security. */
public record ApiError(
        String error,
        String message,
        Instant timestamp,
        String path) {

    public static ApiError de(String error, String message, String path) {
        return new ApiError(error, message, Instant.now(), path);
    }
}
