package com.tuckersoft.branchengine.event;

import com.tuckersoft.branchengine.domain.Decision;
import com.tuckersoft.branchengine.domain.RealityLog;
import com.tuckersoft.branchengine.repository.DecisionRepository;
import com.tuckersoft.branchengine.repository.RealityLogRepository;
import com.tuckersoft.branchengine.service.RealityReportMailer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.Instant;

/**
 * Componente aparte del DecisionService: Spring no aplica @Async a llamadas internas,
 * y el service no debe conocer ni JavaMailSender ni este listener.
 *
 * AFTER_COMMIT: el evento solo se procesa cuando PostgreSQL ya confirmo la transaccion,
 * asi que la decision existe cuando este hilo la busca. REQUIRES_NEW porque el listener
 * corre fuera de la transaccion original y necesita la suya para que sus saves persistan.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class BranchNotificationListener {

    private final DecisionRepository decisiones;
    private final RealityLogRepository informes;
    private final RealityReportMailer mailer;

    @Async("branchExecutor")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void alCommit(DecisionCommittedEvent evento) {
        Decision decision = decisiones.findById(evento.decisionId()).orElse(null);
        if (decision == null) {
            log.error("[BRANCH-LOG] La decision {} no existe: no se envia informe", evento.decisionId());
            return;
        }

        decision.setStatus(Decision.PROCESANDO);
        decision.setUpdatedAt(Instant.now());
        decisiones.save(decision);

        String asunto = mailer.asunto(evento);
        String estadoFinal;
        try {
            mailer.enviar(evento);

            decision.setStatus(Decision.ESTABILIZADA);
            Instant ahora = Instant.now();
            informes.save(RealityLog.builder()
                    .decision(decision)
                    .recipientEmail(evento.recipientEmail())
                    .subject(asunto)
                    .logStatus(RealityLog.SENT)
                    .errorMessage(null)
                    .sentAt(ahora)
                    .createdAt(ahora)
                    .build());
            estadoFinal = Decision.ESTABILIZADA;
        } catch (Exception e) {
            decision.setStatus(Decision.ERROR);
            informes.save(RealityLog.builder()
                    .decision(decision)
                    .recipientEmail(evento.recipientEmail())
                    .subject(asunto)
                    .logStatus(RealityLog.FAILED)
                    .errorMessage(mensajeDe(e))
                    .sentAt(null)
                    .createdAt(Instant.now())
                    .build());
            estadoFinal = Decision.ERROR;
            log.error("Fallo el envio del Informe de Realidad de la decision {}: {}",
                    evento.decisionId(), mensajeDe(e), e);
        }

        decision.setUpdatedAt(Instant.now());
        decisiones.save(decision);

        System.out.printf(
                "[BRANCH-LOG] Decision ID: %d | Player: %s | Branch: %s | Impact: %s | Unit: %s | Node: %s -> %s | Thread: %s | Status: %s%n",
                evento.decisionId(), evento.playerTag(), evento.branchType(), evento.impactLevel(),
                evento.handlerUnit(), evento.sourceNodeCode(),
                evento.resolvedNodeCode() == null ? "-" : evento.resolvedNodeCode(),
                Thread.currentThread().getName(), estadoFinal);
    }

    private static String mensajeDe(Exception e) {
        String mensaje = e.getMessage();
        return (mensaje == null || mensaje.isBlank()) ? e.getClass().getName() : mensaje;
    }
}
