package com.tuckersoft.branchengine.web;

import com.tuckersoft.branchengine.dto.DecisionRequest;
import com.tuckersoft.branchengine.dto.DecisionResponse;
import com.tuckersoft.branchengine.dto.PageResponse;
import com.tuckersoft.branchengine.dto.RealityLogResponse;
import com.tuckersoft.branchengine.service.DecisionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/decisions")
@RequiredArgsConstructor
public class DecisionController {

    private final DecisionService decisiones;

    /**
     * 201 inmediato: el correo se envia en otro hilo, despues del commit.
     * La cabecera del Modo QA es opcional y un valor desconocido no cambia nada.
     */
    @PostMapping
    public ResponseEntity<DecisionResponse> registrar(
            @Valid @RequestBody DecisionRequest peticion,
            @RequestHeader(value = "X-Bandersnatch-Simulate", required = false) String simular) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(decisiones.registrar(peticion, simular));
    }

    @GetMapping
    public ResponseEntity<PageResponse<DecisionResponse>> listar(
            @RequestParam(required = false) String branchType,
            @RequestParam(required = false) String impactLevel,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Long playthroughId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(
                decisiones.listar(branchType, impactLevel, status, playthroughId, page, size));
    }

    @GetMapping("/{id}")
    public ResponseEntity<DecisionResponse> porId(@PathVariable Long id) {
        return ResponseEntity.ok(decisiones.porId(id));
    }

    @GetMapping("/{id}/reality-logs")
    public ResponseEntity<List<RealityLogResponse>> informes(@PathVariable Long id) {
        return ResponseEntity.ok(decisiones.informesDe(id));
    }
}
