package com.tuckersoft.branchengine.web;

import com.tuckersoft.branchengine.dto.StoryNodeRequest;
import com.tuckersoft.branchengine.dto.StoryNodeResponse;
import com.tuckersoft.branchengine.service.StoryNodeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/nodes")
@RequiredArgsConstructor
public class StoryNodeController {

    private final StoryNodeService nodos;

    /** Solo ROLE_ADMIN. */
    @PostMapping
    public ResponseEntity<StoryNodeResponse> crear(@Valid @RequestBody StoryNodeRequest peticion) {
        return ResponseEntity.status(HttpStatus.CREATED).body(nodos.crear(peticion));
    }

    @GetMapping
    public ResponseEntity<List<StoryNodeResponse>> listar() {
        return ResponseEntity.ok(nodos.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StoryNodeResponse> porId(@PathVariable Long id) {
        return ResponseEntity.ok(nodos.porId(id));
    }
}
