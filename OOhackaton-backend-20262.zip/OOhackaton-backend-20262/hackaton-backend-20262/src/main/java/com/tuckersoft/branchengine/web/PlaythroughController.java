package com.tuckersoft.branchengine.web;

import com.tuckersoft.branchengine.dto.PlaythroughPathResponse;
import com.tuckersoft.branchengine.dto.PlaythroughRequest;
import com.tuckersoft.branchengine.dto.PlaythroughResponse;
import com.tuckersoft.branchengine.service.PlaythroughService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/playthroughs")
@RequiredArgsConstructor
public class PlaythroughController {

    private final PlaythroughService partidas;

    @PostMapping
    public ResponseEntity<PlaythroughResponse> abrir(@Valid @RequestBody PlaythroughRequest peticion) {
        return ResponseEntity.status(HttpStatus.CREATED).body(partidas.abrir(peticion));
    }

    @GetMapping
    public ResponseEntity<List<PlaythroughResponse>> listar() {
        return ResponseEntity.ok(partidas.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlaythroughResponse> porId(@PathVariable Long id) {
        return ResponseEntity.ok(partidas.porId(id));
    }

    @GetMapping("/{id}/path")
    public ResponseEntity<PlaythroughPathResponse> recorrido(@PathVariable Long id) {
        return ResponseEntity.ok(partidas.recorrido(id));
    }
}
