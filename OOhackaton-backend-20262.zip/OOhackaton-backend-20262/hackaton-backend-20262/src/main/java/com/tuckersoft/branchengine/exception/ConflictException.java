package com.tuckersoft.branchengine.exception;

/** 409: unicidad repetida o partida ya FINALIZADA. */
public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
