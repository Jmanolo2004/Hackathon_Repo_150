package com.tuckersoft.branchengine.config;

import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.Instant;

/** Crea al administrador con las credenciales del .env. Si ya existe, no hace nada. */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements ApplicationRunner {

    private final UserRepository usuarios;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.display-name}")
    private String nombreAdmin;

    @Value("${app.admin.email}")
    private String emailAdmin;

    @Value("${app.admin.password}")
    private String passwordAdmin;

    @Override
    public void run(ApplicationArguments args) {
        if (usuarios.existsByEmail(emailAdmin)) {
            log.info("El administrador {} ya existe: no se toca", emailAdmin);
            return;
        }
        User admin = User.builder()
                .email(emailAdmin)
                .password(passwordEncoder.encode(passwordAdmin))
                .displayName(nombreAdmin)
                .role(User.ROLE_ADMIN)
                .createdAt(Instant.now())
                .build();
        usuarios.save(admin);
        log.info("Administrador creado: {}", emailAdmin);
    }
}
