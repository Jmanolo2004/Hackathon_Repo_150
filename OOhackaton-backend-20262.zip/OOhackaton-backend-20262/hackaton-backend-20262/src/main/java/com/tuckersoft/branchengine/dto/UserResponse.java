package com.tuckersoft.branchengine.dto;

import com.tuckersoft.branchengine.domain.User;

import java.time.Instant;

/** Nunca lleva password, ni codificada. */
public record UserResponse(
        Long id,
        String email,
        String displayName,
        String role,
        Instant createdAt) {

    public static UserResponse de(User user) {
        return new UserResponse(user.getId(), user.getEmail(), user.getDisplayName(),
                user.getRole(), user.getCreatedAt());
    }
}
