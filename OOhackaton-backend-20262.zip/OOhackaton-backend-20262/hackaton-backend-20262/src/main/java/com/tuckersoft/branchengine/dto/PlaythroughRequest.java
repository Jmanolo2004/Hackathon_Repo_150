package com.tuckersoft.branchengine.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** No hay campo de usuario: el dueno sale del token. */
public record PlaythroughRequest(

        @NotBlank(message = "playerTag es obligatorio")
        @Size(min = 2, max = 40, message = "playerTag debe tener entre 2 y 40 caracteres")
        String playerTag,

        @NotBlank(message = "startNodeCode es obligatorio")
        String startNodeCode) {
}
