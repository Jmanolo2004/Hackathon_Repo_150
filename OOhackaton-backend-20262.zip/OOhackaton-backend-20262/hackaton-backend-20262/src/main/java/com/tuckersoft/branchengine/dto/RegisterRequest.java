package com.tuckersoft.branchengine.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * El campo 'role' no existe a proposito: quien se registra queda como ROLE_USER.
 * Si el JSON lo trae, Jackson lo ignora y no hay escalada de privilegios.
 */
public record RegisterRequest(

        @NotBlank(message = "el email es obligatorio")
        @Email(message = "el email no tiene un formato valido")
        String email,

        @NotBlank(message = "la clave es obligatoria")
        @Size(min = 6, message = "la clave debe tener al menos 6 caracteres")
        String password,

        @NotBlank(message = "el nombre visible es obligatorio")
        @Size(min = 3, max = 60, message = "el nombre visible debe tener entre 3 y 60 caracteres")
        String displayName) {
}
