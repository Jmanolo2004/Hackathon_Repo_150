package com.tuckersoft.branchengine.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;

/** 401 con cuerpo: Spring Security los devuelve vacios si no se registra esto. */
@Component
@RequiredArgsConstructor
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ApiErrorResponder responder;

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException excepcion) throws IOException {
        responder.escribir(request, response, HttpStatus.UNAUTHORIZED.value(), "UNAUTHORIZED",
                "Se requiere un token valido en la cabecera Authorization: Bearer <token>");
    }
}
