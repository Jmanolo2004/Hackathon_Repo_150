package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.dto.UserResponse;
import com.tuckersoft.branchengine.exception.BadRequestException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import com.tuckersoft.branchengine.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class UserService {

    private static final Set<String> ROLES_VALIDOS = Set.of(User.ROLE_USER, User.ROLE_ADMIN);

    private final UserRepository usuarios;
    private final CurrentUserService usuarioActual;

    @Transactional(readOnly = true)
    public UserResponse yo() {
        return UserResponse.de(usuarioActual.obtener());
    }

    @Transactional(readOnly = true)
    public List<UserResponse> listar() {
        return usuarios.findAllByOrderByIdAsc().stream().map(UserResponse::de).toList();
    }

    @Transactional
    public UserResponse cambiarRol(Long id, String rol) {
        if (rol == null || !ROLES_VALIDOS.contains(rol)) {
            throw new BadRequestException("El rol debe ser ROLE_USER o ROLE_ADMIN");
        }
        User objetivo = usuarios.findById(id)
                .orElseThrow(() -> new NotFoundException("No existe el usuario " + id));

        User actual = usuarioActual.obtener();
        if (objetivo.getId().equals(actual.getId())) {
            throw new BadRequestException(
                    "Un administrador no puede cambiar su propio rol: el sistema se quedaria sin administradores");
        }
        objetivo.setRole(rol);
        usuarios.save(objetivo);
        return UserResponse.de(objetivo);
    }
}
