package com.tuckersoft.branchengine.repository;

import com.tuckersoft.branchengine.domain.Playthrough;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlaythroughRepository extends JpaRepository<Playthrough, Long> {

    boolean existsByPlayerTag(String playerTag);

    /** Las del usuario del token: se filtra en el repositorio, no en memoria. */
    List<Playthrough> findByUserIdOrderByCreatedAtDescIdDesc(Long userId);

    List<Playthrough> findAllByOrderByCreatedAtDescIdDesc();
}
