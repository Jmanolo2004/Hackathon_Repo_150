package com.tuckersoft.branchengine.exception;

/** 404: el recurso no existe. */
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
