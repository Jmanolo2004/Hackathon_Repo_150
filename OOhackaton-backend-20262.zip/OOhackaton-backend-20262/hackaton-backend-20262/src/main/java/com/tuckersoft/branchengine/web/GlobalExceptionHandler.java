package com.tuckersoft.branchengine.web;

import com.tuckersoft.branchengine.dto.ApiError;
import com.tuckersoft.branchengine.exception.BadRequestException;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.exception.ForbiddenException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.stream.Collectors;

/** Un solo formato de error para toda la API. */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private ResponseEntity<ApiError> respuesta(HttpStatus estado, String error, String mensaje,
                                               HttpServletRequest request) {
        return ResponseEntity.status(estado)
                .body(ApiError.de(error, mensaje, request.getRequestURI()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> validacion(MethodArgumentNotValidException e,
                                               HttpServletRequest request) {
        String detalle = e.getBindingResult().getFieldErrors().stream()
                .map(f -> f.getField() + ": " + f.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return respuesta(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR",
                detalle.isBlank() ? "La peticion no paso la validacion" : detalle, request);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiError> restriccion(ConstraintViolationException e,
                                                HttpServletRequest request) {
        return respuesta(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", e.getMessage(), request);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class,
            MethodArgumentTypeMismatchException.class,
            MissingServletRequestParameterException.class})
    public ResponseEntity<ApiError> cuerpoIlegible(Exception e, HttpServletRequest request) {
        return respuesta(HttpStatus.BAD_REQUEST, "MALFORMED_REQUEST",
                "La peticion no se puede interpretar: revisa los tipos y los valores permitidos",
                request);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ApiError> peticionInvalida(BadRequestException e,
                                                     HttpServletRequest request) {
        return respuesta(HttpStatus.BAD_REQUEST, "BAD_REQUEST", e.getMessage(), request);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ApiError> noEncontrado(NotFoundException e, HttpServletRequest request) {
        return respuesta(HttpStatus.NOT_FOUND, "NOT_FOUND", e.getMessage(), request);
    }

    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ApiError> conflicto(ConflictException e, HttpServletRequest request) {
        return respuesta(HttpStatus.CONFLICT, "CONFLICT", e.getMessage(), request);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiError> integridad(DataIntegrityViolationException e,
                                               HttpServletRequest request) {
        return respuesta(HttpStatus.CONFLICT, "CONFLICT",
                "El recurso viola una restriccion de unicidad", request);
    }

    @ExceptionHandler({ForbiddenException.class, AccessDeniedException.class})
    public ResponseEntity<ApiError> prohibido(Exception e, HttpServletRequest request) {
        String mensaje = e instanceof ForbiddenException
                ? e.getMessage()
                : "No tienes permisos para acceder a este recurso";
        return respuesta(HttpStatus.FORBIDDEN, "FORBIDDEN", mensaje, request);
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiError> credenciales(AuthenticationException e,
                                                 HttpServletRequest request) {
        // No se revela si fallo el email o la clave.
        return respuesta(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED",
                "Credenciales incorrectas", request);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> inesperado(Exception e, HttpServletRequest request) {
        log.error("Error no controlado en {}", request.getRequestURI(), e);
        return respuesta(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR",
                "Error interno del motor de ramas", request);
    }
}
