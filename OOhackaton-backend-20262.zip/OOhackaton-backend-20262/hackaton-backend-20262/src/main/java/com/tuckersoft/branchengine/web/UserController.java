package com.tuckersoft.branchengine.web;

import com.tuckersoft.branchengine.dto.RoleUpdateRequest;
import com.tuckersoft.branchengine.dto.UserResponse;
import com.tuckersoft.branchengine.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<UserResponse> yo() {
        return ResponseEntity.ok(userService.yo());
    }

    /** Solo ROLE_ADMIN: la regla vive en el SecurityFilterChain. */
    @GetMapping
    public ResponseEntity<List<UserResponse>> listar() {
        return ResponseEntity.ok(userService.listar());
    }

    @PatchMapping("/{id}/role")
    public ResponseEntity<UserResponse> cambiarRol(@PathVariable Long id,
                                                   @Valid @RequestBody RoleUpdateRequest peticion) {
        return ResponseEntity.ok(userService.cambiarRol(id, peticion.role()));
    }
}
