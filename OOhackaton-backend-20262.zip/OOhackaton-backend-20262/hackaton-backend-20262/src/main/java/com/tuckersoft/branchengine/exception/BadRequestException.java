package com.tuckersoft.branchengine.exception;

/** 400: regla de negocio incumplida (por ejemplo, un nodo lleno). */
public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
