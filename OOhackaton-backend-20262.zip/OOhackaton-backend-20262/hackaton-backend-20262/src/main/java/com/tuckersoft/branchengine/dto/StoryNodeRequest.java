package com.tuckersoft.branchengine.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record StoryNodeRequest(

        @NotBlank(message = "nodeCode es obligatorio")
        @Size(min = 3, max = 40, message = "nodeCode debe tener entre 3 y 40 caracteres")
        String nodeCode,

        @NotBlank(message = "title es obligatorio")
        @Size(min = 3, max = 80, message = "title debe tener entre 3 y 80 caracteres")
        String title,

        @NotBlank(message = "sceneText es obligatorio")
        @Size(min = 10, message = "sceneText debe tener al menos 10 caracteres")
        String sceneText,

        @NotNull(message = "branchCapacity es obligatorio")
        @Min(value = 1, message = "branchCapacity debe ser mayor a 0")
        Integer branchCapacity,

        String primaryBranchCode,

        String glitchBranchCode) {
}
