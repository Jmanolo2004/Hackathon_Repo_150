package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.Decision;
import com.tuckersoft.branchengine.domain.Playthrough;
import com.tuckersoft.branchengine.domain.StoryNode;
import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.dto.PathStepResponse;
import com.tuckersoft.branchengine.dto.PlaythroughPathResponse;
import com.tuckersoft.branchengine.dto.PlaythroughRequest;
import com.tuckersoft.branchengine.dto.PlaythroughResponse;
import com.tuckersoft.branchengine.exception.BadRequestException;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.exception.ForbiddenException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import com.tuckersoft.branchengine.repository.DecisionRepository;
import com.tuckersoft.branchengine.repository.PlaythroughRepository;
import com.tuckersoft.branchengine.repository.StoryNodeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PlaythroughService {

    private final PlaythroughRepository partidas;
    private final StoryNodeRepository nodos;
    private final DecisionRepository decisiones;
    private final CurrentUserService usuarioActual;

    @Transactional
    public PlaythroughResponse abrir(PlaythroughRequest peticion) {
        User dueno = usuarioActual.obtener();

        StoryNode nodo = nodos.findByNodeCode(peticion.startNodeCode())
                .orElseThrow(() -> new NotFoundException(
                        "No existe el nodo " + peticion.startNodeCode()));

        if (partidas.existsByPlayerTag(peticion.playerTag())) {
            throw new ConflictException("Ya existe una partida con la etiqueta " + peticion.playerTag());
        }
        if (nodo.estaLleno()) {
            throw new BadRequestException("El nodo " + nodo.getNodeCode()
                    + " ya no admite mas ramas (" + nodo.getCurrentBranches()
                    + "/" + nodo.getBranchCapacity() + ")");
        }

        Instant ahora = Instant.now();
        Playthrough partida = Playthrough.builder()
                .playerTag(peticion.playerTag())
                .user(dueno)
                .startNodeCode(nodo.getNodeCode())
                .currentNode(nodo)
                .lucidity(100)
                .controlLevel(0)
                .status(Playthrough.ACTIVA)
                .endingCode(null)
                .createdAt(ahora)
                .updatedAt(ahora)
                .build();

        nodo.setCurrentBranches(nodo.getCurrentBranches() + 1);
        nodos.save(nodo);

        return PlaythroughResponse.de(partidas.save(partida));
    }

    /** El usuario normal ve las suyas; el administrador supervisa todas. */
    @Transactional(readOnly = true)
    public List<PlaythroughResponse> listar() {
        User actual = usuarioActual.obtener();
        List<Playthrough> resultado = usuarioActual.esAdmin(actual)
                ? partidas.findAllByOrderByCreatedAtDescIdDesc()
                : partidas.findByUserIdOrderByCreatedAtDescIdDesc(actual.getId());
        return resultado.stream().map(PlaythroughResponse::de).toList();
    }

    @Transactional(readOnly = true)
    public PlaythroughResponse porId(Long id) {
        return PlaythroughResponse.de(buscarParaLectura(id));
    }

    @Transactional(readOnly = true)
    public PlaythroughPathResponse recorrido(Long id) {
        Playthrough partida = buscarParaLectura(id);

        List<Decision> pasos = decisiones
                .findByPlaythroughIdAndResolvedNodeCodeIsNotNullOrderByCreatedAtAscIdAsc(partida.getId());

        List<PathStepResponse> steps = new ArrayList<>();
        int orden = 1;
        for (Decision d : pasos) {
            steps.add(new PathStepResponse(orden++, d.getId(), d.getNode().getNodeCode(),
                    d.getResolvedNodeCode(), d.getBranchType(), d.getImpactLevel(), d.getCreatedAt()));
        }

        return new PlaythroughPathResponse(partida.getId(), partida.getPlayerTag(),
                partida.getStatus(), partida.getEndingCode(), partida.getStartNodeCode(),
                partida.getCurrentNode().getNodeCode(), steps);
    }

    /** Leer: el dueno o el administrador, que supervisa. */
    private Playthrough buscarParaLectura(Long id) {
        Playthrough partida = partidas.findById(id)
                .orElseThrow(() -> new NotFoundException("No existe la partida " + id));
        User actual = usuarioActual.obtener();
        if (!usuarioActual.esAdmin(actual)
                && !partida.getUser().getId().equals(actual.getId())) {
            throw new ForbiddenException("Esa partida pertenece a otro analista");
        }
        return partida;
    }
}
