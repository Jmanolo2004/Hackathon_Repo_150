package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.event.DecisionCommittedEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

/** Arma y envia el Informe de Realidad con JavaMailSender. */
@Component
@RequiredArgsConstructor
public class RealityReportMailer {

    private final JavaMailSender mailSender;

    public String asunto(DecisionCommittedEvent e) {
        return "[TUCKERSOFT] " + e.branchType() + " en " + e.playerTag()
                + " | Impacto " + e.impactLevel();
    }

    public String cuerpo(DecisionCommittedEvent e) {
        String separador = "━".repeat(36);
        return """
                Hola %s,

                Una partida de prueba acaba de ramificarse.

                %s
                Decision ID      : #%d
                Jugador          : %s
                Rama             : %s
                Impacto          : %s
                Departamento     : %s
                Consecuencia     : %s
                Nodo origen      : %s
                Nodo destino     : %s
                Estado partida   : %s
                Lucidez          : %d/100
                Nivel de control : %d/100
                Final            : %s
                Registrada       : %s
                %s

                Decisión original del jugador:
                "%s"

                — Tuckersoft Branch Engine, 1984
                """.formatted(
                e.displayName(), separador, e.decisionId(), e.playerTag(), e.branchType(),
                e.impactLevel(), e.handlerUnit(), e.outcomeCode(), e.sourceNodeCode(),
                valor(e.resolvedNodeCode()), e.playthroughStatus(), e.lucidity(),
                e.controlLevel(), valor(e.endingCode()), e.createdAt(), separador, e.rawInput());
    }

    private static String valor(String texto) {
        return texto == null ? "-" : texto;
    }

    /**
     * Envia de verdad. En Modo QA lanza una excepcion real, para que la atrape el mismo
     * catch del listener que atraparia un fallo de SMTP de verdad.
     */
    public void enviar(DecisionCommittedEvent e) {
        if (e.simularFalloDeCorreo()) {
            throw new MailSendException(
                    "Fallo de SMTP simulado por la cabecera X-Bandersnatch-Simulate: MAIL_FAILURE");
        }
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setTo(e.recipientEmail());
        mensaje.setSubject(asunto(e));
        mensaje.setText(cuerpo(e));
        mailSender.send(mensaje);
    }
}
