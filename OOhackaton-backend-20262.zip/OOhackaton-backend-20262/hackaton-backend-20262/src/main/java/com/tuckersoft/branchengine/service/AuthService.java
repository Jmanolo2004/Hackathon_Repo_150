package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.config.JwtService;
import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.dto.AuthResponse;
import com.tuckersoft.branchengine.dto.LoginRequest;
import com.tuckersoft.branchengine.dto.RegisterRequest;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository usuarios;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    @Transactional
    public AuthResponse registrar(RegisterRequest peticion) {
        if (usuarios.existsByEmail(peticion.email())) {
            throw new ConflictException("Ya existe un analista registrado con ese email");
        }
        User nuevo = User.builder()
                .email(peticion.email())
                .password(passwordEncoder.encode(peticion.password()))
                .displayName(peticion.displayName())
                // El rol se fija aqui, nunca se copia del request.
                .role(User.ROLE_USER)
                .createdAt(Instant.now())
                .build();
        usuarios.save(nuevo);
        return AuthResponse.bearer(jwtService.generarToken(nuevo.getEmail()),
                nuevo.getEmail(), nuevo.getDisplayName(), nuevo.getRole());
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest peticion) {
        // Lanza AuthenticationException -> 401, sin distinguir email de clave.
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(peticion.email(), peticion.password()));

        User usuario = usuarios.findByEmail(peticion.email()).orElseThrow();
        return AuthResponse.bearer(jwtService.generarToken(usuario.getEmail()),
                usuario.getEmail(), usuario.getDisplayName(), usuario.getRole());
    }
}
