package com.tuckersoft.branchengine.config;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * El token lleva SOLO la identidad (el email en el subject).
 * El rol no viaja en el JWT: se carga de la base de datos en cada peticion, asi que
 * promover a un usuario surte efecto con su token actual, sin volver a iniciar sesion.
 */
@Service
public class JwtService {

    private final SecretKey clave;
    private final long expiracionMs;

    public JwtService(@Value("${jwt.secret}") String secreto,
                      @Value("${jwt.expiration-ms:7200000}") long expiracionMs) {
        this.clave = construirClave(secreto);
        this.expiracionMs = expiracionMs;
    }

    private static SecretKey construirClave(String secreto) {
        byte[] bytes = secreto.getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 32) {
            // HS256 exige 256 bits: mejor fallar al arrancar que firmar con una clave debil.
            throw new IllegalStateException(
                    "JWT_SECRET debe tener al menos 32 caracteres (tiene " + bytes.length + ")");
        }
        return Keys.hmacShaKeyFor(bytes);
    }

    public String generarToken(String email) {
        Date ahora = new Date();
        return Jwts.builder()
                .subject(email)
                .issuedAt(ahora)
                .expiration(new Date(ahora.getTime() + expiracionMs))
                .signWith(clave)
                .compact();
    }

    /** Lanza JwtException si la firma no cuadra o el token vencio. */
    public String extraerEmail(String token) {
        return Jwts.parser()
                .verifyWith(clave)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }
}
