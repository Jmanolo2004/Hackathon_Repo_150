package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.Decision;
import com.tuckersoft.branchengine.domain.Playthrough;
import com.tuckersoft.branchengine.domain.StoryNode;
import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.dto.DecisionRequest;
import com.tuckersoft.branchengine.dto.DecisionResponse;
import com.tuckersoft.branchengine.dto.PageResponse;
import com.tuckersoft.branchengine.dto.RealityLogResponse;
import com.tuckersoft.branchengine.event.DecisionCommittedEvent;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.exception.ForbiddenException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import com.tuckersoft.branchengine.repository.DecisionRepository;
import com.tuckersoft.branchengine.repository.PlaythroughRepository;
import com.tuckersoft.branchengine.repository.RealityLogRepository;
import com.tuckersoft.branchengine.repository.StoryNodeRepository;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** El motor: clasifica, recalcula la partida y publica el evento del Informe de Realidad. */
@Service
@RequiredArgsConstructor
public class DecisionService {

    public static final String ENDING_PAC_SYMBOL = "ENDING_PAC_SYMBOL";
    public static final String ENDING_WHITE_BEAR = "ENDING_WHITE_BEAR";
    public static final String ENDING_NETFLIX_CUT = "ENDING_NETFLIX_CUT";

    private final DecisionRepository decisiones;
    private final PlaythroughRepository partidas;
    private final StoryNodeRepository nodos;
    private final RealityLogRepository informes;
    private final BranchClassifier clasificador;
    private final CurrentUserService usuarioActual;
    private final ApplicationEventPublisher publicador;

    @Transactional
    public DecisionResponse registrar(DecisionRequest peticion, String simular) {
        // 1. Usuario del token y propiedad de la partida.
        User actual = usuarioActual.obtener();
        Playthrough partida = partidas.findById(peticion.playthroughId())
                .orElseThrow(() -> new NotFoundException(
                        "No existe la partida " + peticion.playthroughId()));

        // Supervisar no es jugar: decidir sobre una partida ajena es 403 incluso para el admin.
        if (!partida.getUser().getId().equals(actual.getId())) {
            throw new ForbiddenException("Solo el dueno de la partida puede decidir sobre ella");
        }
        // 2. La partida tiene que estar ACTIVA.
        if (partida.estaFinalizada()) {
            throw new ConflictException("La partida " + partida.getId()
                    + " ya esta FINALIZADA y no acepta mas decisiones");
        }

        // 3. Clasificar y derivar unidad y consecuencia.
        String rama = clasificador.clasificar(peticion.rawInput());
        StoryNode origen = partida.getCurrentNode();
        Instant ahora = Instant.now();

        Decision decision = Decision.builder()
                .playthrough(partida)
                .node(origen)
                .rawInput(peticion.rawInput())
                .branchType(rama)
                .impactLevel(peticion.impactLevel())
                .handlerUnit(clasificador.unidadDe(rama))
                .outcomeCode(clasificador.consecuenciaDe(rama))
                .status(Decision.REGISTRADA)
                .createdAt(ahora)
                .updatedAt(ahora)
                .build();

        // 4. Entrada corrupta: se guarda y se descarta. No toca la partida ni publica evento.
        if (BranchClassifier.ENTRADA_CORRUPTA.equals(rama)) {
            decision.setResolvedNodeCode(null);
            decision.setStatus(Decision.ERROR);
            return DecisionResponse.de(decisiones.save(decision));
        }

        // 5. Stats, nodo destino y estado de la partida.
        aplicarStats(partida, peticion.impactLevel());

        String destino = usaRamaGlitch(rama, peticion.impactLevel())
                ? origen.getGlitchBranchCode()
                : origen.getPrimaryBranchCode();
        decision.setResolvedNodeCode(destino);

        StoryNode nodoDestino = destino == null ? null
                : nodos.findByNodeCode(destino).orElse(null);

        // El orden es parte del contrato: control, luego lucidez, luego rama sin salida.
        if (partida.getControlLevel() >= 100) {
            finalizar(partida, ENDING_PAC_SYMBOL);
        } else if (partida.getLucidity() <= 0) {
            finalizar(partida, ENDING_WHITE_BEAR);
        } else if (nodoDestino == null) {
            finalizar(partida, ENDING_NETFLIX_CUT);
        } else {
            partida.setCurrentNode(nodoDestino);
        }
        partida.setUpdatedAt(Instant.now());

        // 6 y 7. Se guardan partida y decision.
        partidas.save(partida);
        Decision guardada = decisiones.save(decision);

        // 8. Evento: el correo sale despues del COMMIT, en otro hilo.
        publicador.publishEvent(new DecisionCommittedEvent(
                guardada.getId(),
                partida.getUser().getEmail(),
                partida.getUser().getDisplayName(),
                partida.getPlayerTag(),
                guardada.getBranchType(),
                guardada.getImpactLevel(),
                guardada.getHandlerUnit(),
                guardada.getOutcomeCode(),
                origen.getNodeCode(),
                guardada.getResolvedNodeCode(),
                partida.getStatus(),
                partida.getLucidity(),
                partida.getControlLevel(),
                partida.getEndingCode(),
                guardada.getRawInput(),
                guardada.getCreatedAt(),
                "MAIL_FAILURE".equalsIgnoreCase(simular)));

        return DecisionResponse.de(guardada);
    }

    private static boolean usaRamaGlitch(String rama, String impacto) {
        return BranchClassifier.RUPTURA_CUARTA_PARED.equals(rama) || "CRITICO".equals(impacto);
    }

    private static void aplicarStats(Playthrough partida, String impacto) {
        int lucidez;
        int control;
        switch (impacto) {
            case "LEVE" -> { lucidez = -5; control = 5; }
            case "MODERADO" -> { lucidez = -15; control = 10; }
            case "GRAVE" -> { lucidez = -30; control = 20; }
            case "CRITICO" -> { lucidez = -40; control = 45; }
            default -> throw new IllegalArgumentException("Impacto desconocido: " + impacto);
        }
        partida.setLucidity(Math.max(0, Math.min(100, partida.getLucidity() + lucidez)));
        partida.setControlLevel(Math.max(0, Math.min(100, partida.getControlLevel() + control)));
    }

    private static void finalizar(Playthrough partida, String endingCode) {
        partida.setStatus(Playthrough.FINALIZADA);
        partida.setEndingCode(endingCode);
        // currentNode no cambia cuando la partida termina.
    }

    // ------------------------------------------------------------------ lecturas

    @Transactional(readOnly = true)
    public PageResponse<DecisionResponse> listar(String branchType, String impactLevel, String status,
                                                 Long playthroughId, int page, int size) {
        User actual = usuarioActual.obtener();
        Long duenoFiltrado = usuarioActual.esAdmin(actual) ? null : actual.getId();

        Specification<Decision> filtro = (raiz, consulta, cb) -> {
            List<Predicate> condiciones = new ArrayList<>();
            if (duenoFiltrado != null) {
                condiciones.add(cb.equal(raiz.get("playthrough").get("user").get("id"), duenoFiltrado));
            }
            if (branchType != null && !branchType.isBlank()) {
                condiciones.add(cb.equal(raiz.get("branchType"), branchType));
            }
            if (impactLevel != null && !impactLevel.isBlank()) {
                condiciones.add(cb.equal(raiz.get("impactLevel"), impactLevel));
            }
            if (status != null && !status.isBlank()) {
                condiciones.add(cb.equal(raiz.get("status"), status));
            }
            if (playthroughId != null) {
                condiciones.add(cb.equal(raiz.get("playthrough").get("id"), playthroughId));
            }
            return cb.and(condiciones.toArray(new Predicate[0]));
        };

        Page<Decision> pagina = decisiones.findAll(filtro,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt", "id")));
        return PageResponse.de(pagina, DecisionResponse::de);
    }

    @Transactional(readOnly = true)
    public DecisionResponse porId(Long id) {
        return DecisionResponse.de(buscarParaLectura(id));
    }

    @Transactional(readOnly = true)
    public List<RealityLogResponse> informesDe(Long id) {
        Decision decision = buscarParaLectura(id);
        return informes.findByDecisionIdOrderByCreatedAtAscIdAsc(decision.getId())
                .stream().map(RealityLogResponse::de).toList();
    }

    /** El aislamiento tambien aplica a los recursos hijos; el admin si puede leer. */
    private Decision buscarParaLectura(Long id) {
        Decision decision = decisiones.findById(id)
                .orElseThrow(() -> new NotFoundException("No existe la decision " + id));
        User actual = usuarioActual.obtener();
        if (!usuarioActual.esAdmin(actual)
                && !decision.getPlaythrough().getUser().getId().equals(actual.getId())) {
            throw new ForbiddenException("Esa decision pertenece a la partida de otro analista");
        }
        return decision;
    }
}
