package com.tuckersoft.branchengine.service;

import com.tuckersoft.branchengine.domain.Decision;
import com.tuckersoft.branchengine.domain.Playthrough;
import com.tuckersoft.branchengine.domain.StoryNode;
import com.tuckersoft.branchengine.domain.User;
import com.tuckersoft.branchengine.dto.DecisionRequest;
import com.tuckersoft.branchengine.dto.DecisionResponse;
import com.tuckersoft.branchengine.event.DecisionCommittedEvent;
import com.tuckersoft.branchengine.exception.ConflictException;
import com.tuckersoft.branchengine.exception.ForbiddenException;
import com.tuckersoft.branchengine.exception.NotFoundException;
import com.tuckersoft.branchengine.repository.DecisionRepository;
import com.tuckersoft.branchengine.repository.PlaythroughRepository;
import com.tuckersoft.branchengine.repository.RealityLogRepository;
import com.tuckersoft.branchengine.repository.StoryNodeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.context.ApplicationEventPublisher;

import java.time.Instant;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Tests unitarios del motor. Corren sin PostgreSQL, sin SMTP y sin red: todo lo que toca
 * infraestructura esta mockeado con Mockito.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DecisionServiceTest {

    @Mock private DecisionRepository decisiones;
    @Mock private PlaythroughRepository partidas;
    @Mock private StoryNodeRepository nodos;
    @Mock private RealityLogRepository informes;
    @Mock private CurrentUserService usuarioActual;
    @Mock private ApplicationEventPublisher publicador;

    private DecisionService servicio;
    private User analista;
    private StoryNode origen;
    private StoryNode destinoPrimario;
    private StoryNode destinoGlitch;
    private Playthrough partida;

    @BeforeEach
    void preparar() {
        servicio = new DecisionService(decisiones, partidas, nodos, informes,
                new BranchClassifier(), usuarioActual, publicador);

        analista = User.builder().id(1L).email("ada@tuckersoft.test")
                .displayName("Ada Lovelace").password("$2a$10$hash")
                .role(User.ROLE_USER).createdAt(Instant.now()).build();

        destinoPrimario = nodo(20L, "NODE-BUS");
        destinoGlitch = nodo(30L, "NODE-ESPEJO");
        origen = nodo(10L, "NODE-CEREAL");
        origen.setPrimaryBranchCode("NODE-BUS");
        origen.setGlitchBranchCode("NODE-ESPEJO");

        partida = Playthrough.builder().id(7L).playerTag("STEFAN-01").user(analista)
                .startNodeCode(origen.getNodeCode()).currentNode(origen)
                .lucidity(100).controlLevel(0).status(Playthrough.ACTIVA)
                .createdAt(Instant.now()).updatedAt(Instant.now()).build();

        when(usuarioActual.obtener()).thenReturn(analista);
        when(partidas.findById(7L)).thenReturn(Optional.of(partida));
        when(partidas.save(any(Playthrough.class))).thenAnswer(i -> i.getArgument(0));
        when(nodos.findByNodeCode("NODE-BUS")).thenReturn(Optional.of(destinoPrimario));
        when(nodos.findByNodeCode("NODE-ESPEJO")).thenReturn(Optional.of(destinoGlitch));
        when(decisiones.save(any(Decision.class))).thenAnswer(i -> {
            Decision d = i.getArgument(0);
            if (d.getId() == null) d.setId(99L);
            return d;
        });
    }

    private static StoryNode nodo(Long id, String codigo) {
        return StoryNode.builder().id(id).nodeCode(codigo).title("Escena " + codigo)
                .sceneText("Escena de prueba para " + codigo).branchCapacity(50)
                .currentBranches(0).createdAt(Instant.now()).build();
    }

    private DecisionResponse decidir(String texto, String impacto) {
        return servicio.registrar(new DecisionRequest(7L, texto, impacto), null);
    }

    @Test
    @DisplayName("1. 'Stefan destruye la camara' es RUPTURA_CUARTA_PARED: la regla 2 gana a la 4")
    void precedencia_de_reglas() {
        DecisionResponse res = decidir("Stefan destruye la camara", "LEVE");

        assertThat(res.branchType()).isEqualTo("RUPTURA_CUARTA_PARED");
        assertThat(res.handlerUnit()).isEqualTo("Departamento Netflix");
        assertThat(res.outcomeCode()).isEqualTo("BREAK_FOURTH_WALL");
        // Y por ser ruptura, desvia por glitchBranchCode aunque el impacto sea LEVE.
        assertThat(res.resolvedNodeCode()).isEqualTo("NODE-ESPEJO");
    }

    @Test
    @DisplayName("2. Un texto sin letras es ENTRADA_CORRUPTA y no modifica la partida")
    void entrada_corrupta_no_toca_la_partida() {
        DecisionResponse res = decidir("%%%% 01001 ### @@@ 110", "CRITICO");

        assertThat(res.branchType()).isEqualTo("ENTRADA_CORRUPTA");
        assertThat(res.status()).isEqualTo(Decision.ERROR);
        assertThat(res.resolvedNodeCode()).isNull();
        assertThat(res.handlerUnit()).isEqualTo("Archivo de Errores");

        // La partida queda exactamente como estaba, pese al impacto CRITICO del request.
        assertThat(partida.getLucidity()).isEqualTo(100);
        assertThat(partida.getControlLevel()).isZero();
        assertThat(partida.getStatus()).isEqualTo(Playthrough.ACTIVA);
        assertThat(partida.getCurrentNode().getNodeCode()).isEqualTo("NODE-CEREAL");
        verify(partidas, never()).save(any(Playthrough.class));
    }

    @Test
    @DisplayName("3. Un impacto CRITICO baja 40 de lucidez, sube 45 de control y respeta los limites")
    void stats_de_impacto_critico_con_limites() {
        DecisionResponse primera = decidir("Stefan sigue adelante con el guion previsto.", "CRITICO");
        assertThat(primera.lucidity()).isEqualTo(60);
        assertThat(primera.controlLevel()).isEqualTo(45);

        // Los topes: 60-40-40 no puede bajar de 0, y 45+45+45 no puede pasar de 100.
        partida.setLucidity(20);
        partida.setControlLevel(80);
        DecisionResponse topada = decidir("Stefan sigue adelante con el guion previsto.", "CRITICO");
        assertThat(topada.lucidity()).isZero();
        assertThat(topada.controlLevel()).isEqualTo(100);
    }

    @Test
    @DisplayName("4. Con controlLevel en 100 el final es ENDING_PAC_SYMBOL aunque la lucidez sea 0")
    void el_final_por_control_gana_al_final_por_lucidez() {
        partida.setLucidity(40);
        partida.setControlLevel(55);

        DecisionResponse res = decidir("Stefan sigue adelante con el guion previsto.", "CRITICO");

        assertThat(res.lucidity()).isZero();
        assertThat(res.controlLevel()).isEqualTo(100);
        assertThat(res.playthroughStatus()).isEqualTo(Playthrough.FINALIZADA);
        assertThat(res.endingCode()).isEqualTo(DecisionService.ENDING_PAC_SYMBOL);
        // La partida terminada no se mueve de nodo.
        assertThat(partida.getCurrentNode().getNodeCode()).isEqualTo("NODE-CEREAL");
    }

    @Test
    @DisplayName("5. El evento se publica una vez en una decision normal y ninguna en una corrupta")
    void el_evento_solo_se_publica_en_decisiones_validas() {
        decidir("Stefan acepta la oferta y se queda en el estudio.", "LEVE");
        verify(publicador, times(1)).publishEvent(any(DecisionCommittedEvent.class));

        decidir("#### 1010 @@@@", "LEVE");
        // Sigue habiendo una sola publicacion: la corrupta no publica nada.
        verify(publicador, times(1)).publishEvent(any(DecisionCommittedEvent.class));
    }

    @Test
    @DisplayName("6. Sin nodo destino la partida termina en ENDING_NETFLIX_CUT")
    void sin_nodo_destino_termina_en_netflix_cut() {
        origen.setPrimaryBranchCode(null);

        DecisionResponse res = decidir("Stefan acepta la oferta y sigue el guion.", "LEVE");

        assertThat(res.resolvedNodeCode()).isNull();
        assertThat(res.playthroughStatus()).isEqualTo(Playthrough.FINALIZADA);
        assertThat(res.endingCode()).isEqualTo(DecisionService.ENDING_NETFLIX_CUT);
    }

    @Test
    @DisplayName("7. Propiedad y estado: partida ajena 403, inexistente 404, finalizada 409")
    void reglas_de_propiedad_y_estado() {
        User otro = User.builder().id(2L).email("alan@tuckersoft.test").displayName("Alan Turing")
                .password("$2a$10$hash").role(User.ROLE_USER).createdAt(Instant.now()).build();
        when(usuarioActual.obtener()).thenReturn(otro);
        assertThatThrownBy(() -> decidir("Intento decidir sobre una partida ajena.", "LEVE"))
                .isInstanceOf(ForbiddenException.class);

        when(usuarioActual.obtener()).thenReturn(analista);
        when(partidas.findById(404L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> servicio.registrar(
                new DecisionRequest(404L, "Decision sobre una partida inexistente.", "LEVE"), null))
                .isInstanceOf(NotFoundException.class);

        partida.setStatus(Playthrough.FINALIZADA);
        assertThatThrownBy(() -> decidir("Intento seguir jugando tras el final.", "LEVE"))
                .isInstanceOf(ConflictException.class);
    }

    @Test
    @DisplayName("8. La clasificacion normaliza mayusculas y tildes antes de comparar")
    void la_clasificacion_normaliza_el_texto() {
        assertThat(decidir("Stefan mira fijamente la CÁMARA del salón.", "LEVE").branchType())
                .isEqualTo("RUPTURA_CUARTA_PARED");

        partida.setStatus(Playthrough.ACTIVA);
        assertThat(decidir("Stefan cree que lo vigilan desde el televisor.", "LEVE").branchType())
                .isEqualTo("SOSPECHA");
    }
}
